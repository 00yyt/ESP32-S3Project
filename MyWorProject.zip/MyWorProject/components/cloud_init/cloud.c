#include "cloud.h"
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_event.h"
#include "esp_log.h"
#include "led.h"
#include "cJSON.h"


#define TAG "cloud"
#define MQTT_PUBLISH_FORMAT "{\"id\":\"123\",\"params\":{\"%s\":{\"value\":%s}}}"



static esp_mqtt_client_handle_t mqtt_client = NULL;
static EventGroupHandle_t mqtt_event_group;
#define MQTT_CONNECTED_BIT BIT0



// 函数原型声明
void mqtt_subscribe(const char *topic, int qos);



// MQTT 事件处理函数

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    esp_mqtt_event_t *event = event_data;
    
    switch (event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT 连接成功");
            xEventGroupSetBits(mqtt_event_group, MQTT_CONNECTED_BIT);
            // 连接成功后自动订阅主题（支持重连后自动恢复订阅）
            mqtt_subscribe(MQTT_SUBSCRIBE_TOPIC, 0);
            mqtt_subscribe(MQTT_PUBLISH_REPLY_TOPIC, 0);
            break;
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "MQTT 连接断开");
            xEventGroupClearBits(mqtt_event_group, MQTT_CONNECTED_BIT);
            break;
        case MQTT_EVENT_PUBLISHED:
            ESP_LOGI(TAG, "消息发布成功，消息ID: %d", event->msg_id);
            break;
        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "订阅成功，消息ID: %d", event->msg_id);
            break;
        case MQTT_EVENT_DATA:
            if (event->topic && event->data) {
                ESP_LOGI(TAG, "收到消息");
                ESP_LOGI(TAG, "主题: %.*s", event->topic_len, event->topic);
                ESP_LOGI(TAG, "数据: %.*s", event->data_len, event->data);
                
                // 只处理属性设置主题的消息
                if (strncmp(event->topic, MQTT_SUBSCRIBE_TOPIC, event->topic_len) == 0) {
                    ESP_LOGI(TAG, "处理属性设置消息");
                    //handle_property_set(event->data, event->data_len);
                }
            }
            break;
        
        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT 错误: %d", event->error_handle->error_type);
            if (event->error_handle->error_type == MQTT_ERROR_TYPE_CONNECTION_REFUSED) {
                ESP_LOGE(TAG, "连接被拒绝，原因代码: %d", event->error_handle->connect_return_code);
            }
            break;
        default:
            break;  
    }
}

// MQTT 发布函数
esp_err_t mqtt_publish(const char *topic, const char *data, int qos, int retain)
{
    if (!mqtt_client) {
        ESP_LOGE(TAG, "MQTT 客户端未初始化");
        return ESP_FAIL;
    }
    
    if (!topic || !data) {
        ESP_LOGE(TAG, "主题或数据为空");
        return ESP_FAIL;
    }
    
    int msg_id = esp_mqtt_client_publish(mqtt_client, topic, data, 0, qos, retain);
    if (msg_id == -1) {
        ESP_LOGE(TAG, "消息发布失败");
        return ESP_FAIL;
    }
    
    return ESP_OK;
}

// MQTT 订阅函数
void mqtt_subscribe(const char *topic, int qos)
{
    if (!mqtt_client) {
        ESP_LOGE(TAG, "MQTT 客户端未初始化");
        return;
    }
    
    if (!topic) {
        ESP_LOGE(TAG, "订阅主题为空");
        return;
    }
    
    int msg_id = esp_mqtt_client_subscribe(mqtt_client, topic, qos);
    if (msg_id == -1) {
        ESP_LOGE(TAG, "订阅失败");
    } else {
        ESP_LOGI(TAG, "订阅成功，消息ID: %d", msg_id);
    }
}

esp_err_t cloud_init(void)
{
    mqtt_event_group = xEventGroupCreate();
    
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker = {
            .address = {
                .uri = MQTT_BROKER_URL,
            },
        },
        .credentials = {
            .client_id = MQTT_CLIENT_ID,
            .username = MQTT_USERNAME,
            .authentication = {  
            .password = MQTT_PASSWORD,
           }
        },
        .session = {
            .keepalive = 60,
            
        },
        .network = {
            .reconnect_timeout_ms = 10000,
        },
    };
    
    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    
    // 注册事件处理
    esp_mqtt_client_register_event(mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    
    // 启动 MQTT 客户端
    esp_mqtt_client_start(mqtt_client);
    
    ESP_LOGI(TAG, "MQTT 客户端初始化完成，正在连接到: %s", MQTT_BROKER_URL);
    
    // 等待连接成功
    EventBits_t bits = xEventGroupWaitBits(
        mqtt_event_group,
        MQTT_CONNECTED_BIT,
        pdFALSE,
        pdFALSE,
        pdMS_TO_TICKS(30000) // 30秒超时
    );

    // 订阅已移至 MQTT_EVENT_CONNECTED 事件中处理（支持重连自动恢复）

    if (bits & MQTT_CONNECTED_BIT) {
        ESP_LOGI(TAG, "MQTT 连接成功，准备就绪");
        return ESP_OK;
    } else {
        ESP_LOGE(TAG, "MQTT 连接超时");
    }
    return ESP_FAIL;
}