#ifndef __CLOUD_H__
#define __CLOUD_H__

#include "mqtt_client.h"
#include "esp_err.h"

// MQTT 连接参数（用户需要填写）
#define MQTT_BROKER_URL  "mqtt://mqtts.heclouds.com:1883"
#define MQTT_CLIENT_ID "MyWork"
#define MQTT_USERNAME "t8o917c1od" // 如有需要，否则留空
#define MQTT_PASSWORD "version=2018-10-31&res=products%2Ft8o917c1od%2Fdevices%2FMyWork&et=1903608323&method=md5&sign=V7O%2BeH5UTqk7WdMui8U2Fg%3D%3D" // 如有需要，否则留空




// 发布主题（用户需要填写）
#define MQTT_PUBLISH_TOPIC "$sys/"MQTT_USERNAME "/"MQTT_CLIENT_ID "/thing/property/post"


#define MQTT_PUBLISH_REPLY_TOPIC "$sys/"MQTT_USERNAME "/"MQTT_CLIENT_ID "/thing/property/post/reply"


#define MQTT_SUBSCRIBE_TOPIC "$sys/"MQTT_USERNAME "/"MQTT_CLIENT_ID "/thing/property/set"


#define MQTT_SUBSCRIBE_REPLY_TOPIC "$sys/"MQTT_USERNAME "/"MQTT_CLIENT_ID "/thing/property/set_reply"



esp_err_t cloud_init(void);

esp_err_t mqtt_publish(const char *topic, const char *data, int qos, int retain);


#endif









