#include "Buzzer.h"

void Buzzer_Init(void)
{
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << BUZZER_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);
    Buzzer_Off();
}

void Buzzer_On(void)
{
    gpio_set_level(BUZZER_PIN, 1);
}

void Buzzer_Off(void)
{
    gpio_set_level(BUZZER_PIN, 0);
}