#ifndef BUZZER_H
#define BUZZER_H

#include "driver/gpio.h"

#define temp_high_threshold 30.0f
#define temp_low_threshold 10.0f
#define humi_high_threshold 70.0f
#define humi_low_threshold 40.0f


#define BUZZER_PIN GPIO_NUM_7

void Buzzer_Init(void);
void Buzzer_On(void);
void Buzzer_Off(void);



#endif