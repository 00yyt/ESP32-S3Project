#ifndef WIFI_WEB_H
#define WIFI_WEB_H

#include "esp_err.h"

esp_err_t wifi_init(void);

#endif