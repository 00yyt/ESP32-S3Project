#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_http_server.h"
#include "lwip/ip_addr.h"
#include "wifi.h"
#include "led.h"

// --- 配置定义 ---
#define EXAMPLE_ESP_WIFI_SSID "ESP32-Config"
#define EXAMPLE_ESP_WIFI_PASS "" // 空密码 (未使用)
#define EXAMPLE_MAX_STA_CONN 4
#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT BIT1
static const char *TAG = "wifi_init";

// --- 全局变量 ---
static EventGroupHandle_t s_wifi_event_group;
static httpd_handle_t g_server = NULL;



#define AP_SSID "ESP32-S3" // 热点名称
#define AP_PASS "" // 如需密码可改成 WPA2
#define WIFI_CONNECT_TIMEOUT_MS 30000 // 30秒连接超时
#define WIFI_MAX_RETRY 3 // 连接失败重试次数



static esp_netif_t *s_sta_netif = NULL;// STA 网络接口
static esp_netif_t *s_ap_netif = NULL;// AP 网络接口
static int s_retry_count = 0;// 连接失败重试次数
static bool s_prov_started = false;//

static wifi_ap_record_t *s_scan_list = NULL;
static uint16_t s_scan_num = 0;
static bool s_scan_running = false;

static void start_ap(void);

// 释放扫描缓存
static void scan_free_cache(void) {
    if (s_scan_list) {
        free(s_scan_list);
        s_scan_list = NULL;
    }
    s_scan_num = 0;
}

// 重要：在 APSTA 模式下扫描并缓存结果，保持 AP 不掉线（不切模式，不关 AP）
static void scan_and_cache_apsta_keep_ap(void) {
    // 关键目标：保持 SoftAP 不掉线（不切模式，不关 AP），只用 STA 在 APSTA 模式下扫描并缓存
    scan_free_cache();

    (void)esp_wifi_scan_stop();

    wifi_scan_config_t scan_config = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
    };

    esp_err_t err = esp_wifi_scan_start(&scan_config, true /* block */);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "扫描失败: %s", esp_err_to_name(err));
        return;
    }

    uint16_t ap_num = 0;
    err = esp_wifi_scan_get_ap_num(&ap_num);
    if (err != ESP_OK || ap_num == 0) {
        ESP_LOGW(TAG, "扫描结果为空，数量:%u, err:%s", (unsigned)ap_num, esp_err_to_name(err));
        return;
    }

    wifi_ap_record_t *list = malloc(sizeof(wifi_ap_record_t) * ap_num);
    if (!list) {
        ESP_LOGW(TAG, "内存不足，无法保存扫描结果(%u)", (unsigned)ap_num);
        return;
    }

    uint16_t out_num = ap_num;
    err = esp_wifi_scan_get_ap_records(&out_num, list);
    if (err != ESP_OK) {
        free(list);
        ESP_LOGW(TAG, "读取扫描记录失败: %s", esp_err_to_name(err));
        return;
    }

    s_scan_list = list;
    s_scan_num = out_num;
    ESP_LOGI(TAG, "扫描完成，缓存 AP 数量: %u", (unsigned)s_scan_num);
}

static void scan_task(void *arg) {
    (void)arg;
    s_scan_running = true;
    scan_and_cache_apsta_keep_ap();
    s_scan_running = false;
    vTaskDelete(NULL);
}

static void trigger_scan_async(void) {
    if (s_scan_running) return;
    // 低优先级后台扫，避免在事件回调里阻塞
    (void)xTaskCreate(scan_task, "wifi_scan", 4096, NULL, 2, NULL);
}

// --- HTTP 请求处理函数 ---

// 根路径处理器：显示 WiFi 列表
// 注意：这里删除了原来的旧版本，只保留这一个定义
static esp_err_t root_handler(httpd_req_t *req) { 
    char buf[768];
    ESP_LOGI(TAG, "页面请求：缓存 AP 数量=%u", (unsigned)s_scan_num);
    // 页面头部 + 输入框（支持手输/点击填充）
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    esp_err_t err = httpd_resp_sendstr_chunk(req,
                       "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                       "<meta name='viewport' content='width=device-width, initial-scale=1' />"
                       "<title>WiFi 配网</title>"
                       "<style>"
                       "body{font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:18px auto;padding:0 12px;}"
                       "h1{font-size:26px;margin:6px 0 12px 0;}"
                       ".row{margin:10px 0;}"
                       "input{width:100%;padding:12px 10px;font-size:16px;box-sizing:border-box;}"
                       ".btn{width:100%;padding:12px 10px;font-size:16px;margin-top:10px;}"
                       ".link{display:inline-block;margin:8px 0;}"
                       ".ssidbtn{width:100%;padding:12px 10px;text-align:left;margin:6px 0;border:1px solid #ccc;background:#f6f6f6;}"
                       ".muted{color:#666;font-size:14px;}"
                       "</style>"
                       "</head><body>"
                       "<h1>📶 请选择 WiFi</h1>"
                       "<div class='row'><a class='link' href='/rescan'>重新扫描</a></div>"
                       "<form action='/save' method='get' autocomplete='on'>"
                       "<div class='row'><div class='muted'>SSID（可手动输入，或点下面列表自动填充）</div>"
                       "<input id='ssid' name='ssid' placeholder='WiFi 名称(SSID)' /></div>"
                       "<div class='row'><div class='muted'>密码（开放网络可留空）</div>"
                       "<input id='pass' name='pass' type='password' placeholder='WiFi 密码' /></div>"
                       "<button class='btn' type='submit'>连接 / 保存</button>"
                       "</form>"
                       "<hr/>"
                       "<div class='muted'>扫描到的 WiFi（点击填充 SSID）</div>"
                       "<script>"
                       "function pick(ssid){document.getElementById('ssid').value=ssid;document.getElementById('pass').focus();}"
                       "</script>");
    if (err != ESP_OK) return err;

    if (s_scan_num > 0 && s_scan_list) {
        for (int i = 0; i < (int)s_scan_num && i < 50; i++) {
            char ssid_str[33] = {0};
            memcpy(ssid_str, s_scan_list[i].ssid, 32);
            if (ssid_str[0] == '\0') continue;
            // 用按钮触发 JS 填充 SSID
            snprintf(buf, sizeof(buf),
                    "<button class='ssidbtn' type='button' onclick=\"pick('%s')\">%s (信号: %d)</button>",
                    ssid_str, ssid_str, s_scan_list[i].rssi);
            err = httpd_resp_sendstr_chunk(req, buf);
            if (err != ESP_OK) return err;
        }
    } else {
        err = httpd_resp_sendstr_chunk(req,
                           "<p class='muted'>🔍 暂无扫描结果。请点上方“重新扫描”。</p>"
                           "<p class='muted'>提示：重新扫描会短暂切换 WiFi 状态，可能需要手机/电脑重新连一次热点。</p>");
        if (err != ESP_OK) return err;
    }

    err = httpd_resp_sendstr_chunk(req, "</body></html>");
    if (err != ESP_OK) return err;
    return httpd_resp_sendstr_chunk(req, NULL);
    // return ESP_OK;
}

// 重新扫描处理器
static esp_err_t rescan_handler(httpd_req_t *req) {
    // 保持 APSTA，不切模式，避免断开手机/电脑的配网热点连接
    scan_and_cache_apsta_keep_ap();

    httpd_resp_set_status(req, "302 Found");
    httpd_resp_set_hdr(req, "Location", "/");
    httpd_resp_sendstr(req, "Redirect");
    return ESP_OK;
}

// 输入密码页面
static esp_err_t input_handler(httpd_req_t *req) {
    char buf[256];
    if (httpd_req_get_url_query_str(req, buf, sizeof(buf)) != ESP_OK) {
        httpd_resp_sendstr(req, "Bad Request");
        return ESP_OK;
    }
    char ssid[64] = {0};
    httpd_query_key_value(buf, "ssid", ssid, sizeof(ssid));
    
    char page[512];
    sprintf(page, "<!DOCTYPE html><html><head><meta charset='utf-8'></head><body><h1>🔑 连接 %s</h1>"
                  "<form action='/save'>"
                  "<input type='hidden' name='ssid' value='%s'>"
                  "密码: <input type='password' name='pass' style='padding:5px; width:80%%; margin:10px 0;'>"
                  "<br><button type='submit' style='padding:10px;'>连接</button>"
                  "</form></body></html>", ssid, ssid);
    httpd_resp_send(req, page, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}
// 保存处理器
static esp_err_t save_handler(httpd_req_t *req) {
    char query[256] = {0};
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK) {
        httpd_resp_set_status(req, "400 Bad Request");
        httpd_resp_sendstr(req, "Missing query string");
        return ESP_OK;
    }

    char ssid[33] = {0};
    char pass[65] = {0};
    if (httpd_query_key_value(query, "ssid", ssid, sizeof(ssid)) != ESP_OK) {
        httpd_resp_set_status(req, "400 Bad Request");
        httpd_resp_sendstr(req, "Missing ssid");
        return ESP_OK;
    }
    // pass 允许为空（开放网络）
    (void)httpd_query_key_value(query, "pass", pass, sizeof(pass));

    // 保存配置到 NVS（统一 key：ssid / pass）
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open("wifi", NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) {
        httpd_resp_set_status(req, "500 Internal Server Error");
        httpd_resp_sendstr(req, "NVS open failed");
        return ESP_OK;
    }
    err = nvs_set_str(nvs_handle, "ssid", ssid);
    if (err == ESP_OK) err = nvs_set_str(nvs_handle, "pass", pass);
    if (err == ESP_OK) err = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);

    if (err != ESP_OK) {
        httpd_resp_set_status(req, "500 Internal Server Error");
        httpd_resp_sendstr(req, "NVS write failed");
        return ESP_OK;
    }

    // 立刻尝试连接（保持 APSTA，连上后会自动关闭配网 AP/网页）
    wifi_config_t sta_conf = {0};
    strncpy((char *)sta_conf.sta.ssid, ssid, sizeof(sta_conf.sta.ssid) - 1);
    strncpy((char *)sta_conf.sta.password, pass, sizeof(sta_conf.sta.password) - 1);
    sta_conf.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    sta_conf.sta.pmf_cfg.capable = true;
    sta_conf.sta.pmf_cfg.required = false;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta_conf));
    s_retry_count = 0;
    xEventGroupClearBits(s_wifi_event_group, WIFI_CONNECTED_BIT | WIFI_FAIL_BIT);
    esp_wifi_connect();

    httpd_resp_sendstr(req,
                       "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                       "<meta http-equiv='refresh' content='3;url=/'/>"
                       "</head><body><h1>✅ 已保存，正在连接...</h1>"
                       "<p>如果连接成功，设备将退出配网热点。</p>"
                       "<p>页面将自动刷新。</p></body></html>");
    return ESP_OK;
} 


// 图标处理（防止报错）
static esp_err_t favicon_handler(httpd_req_t *req) {
    httpd_resp_set_type(req, "image/x-icon");
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}

// --- WiFi 初始化与事件处理 ---

static void stop_server(void) {
    if (g_server) {
        httpd_stop(g_server);
        g_server = NULL;
    }
}

static void start_server(void); // 前置声明

static void start_ap(void) {
    if (!s_ap_netif) {
        s_ap_netif = esp_netif_create_default_wifi_ap();
    }

    wifi_config_t ap_conf = {0};
    strncpy((char *)ap_conf.ap.ssid, AP_SSID, sizeof(ap_conf.ap.ssid) - 1);
    ap_conf.ap.ssid_len = strlen(AP_SSID);
    ap_conf.ap.max_connection = EXAMPLE_MAX_STA_CONN;
    ap_conf.ap.beacon_interval = 100;

    if (strlen(AP_PASS) == 0) {
        ap_conf.ap.authmode = WIFI_AUTH_OPEN;
    } else {
        strncpy((char *)ap_conf.ap.password, AP_PASS, sizeof(ap_conf.ap.password) - 1);
        ap_conf.ap.authmode = WIFI_AUTH_WPA2_PSK;
    }

    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap_conf));
    ESP_LOGI(TAG, "AP 配网模式已启动，SSID: %s", AP_SSID);
}

static void ensure_provisioning_started(void) {
    if (s_prov_started) return;
    s_prov_started = true;

    ESP_LOGW(TAG, "进入配网模式：启动 AP + 网页配网");

    // 进入 APSTA（网页配网）
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
    start_ap();
    start_server();

    // 后台触发扫描：保持 AP 不掉线，页面可看到列表
    trigger_scan_async();
}

static void ensure_provisioning_stopped(void) {
    if (!s_prov_started) return;
    s_prov_started = false;

    ESP_LOGI(TAG, "已联网：关闭配网网页并关闭 AP");
    stop_server();

    // 只保留 STA
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    if (s_ap_netif) {
        esp_netif_destroy(s_ap_netif);
        s_ap_netif = NULL;
    }
}

// WiFi事件处理函数
static void wifi_event_handler_sta(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT) {
        switch (event_id) {
            case WIFI_EVENT_STA_START:
                ESP_LOGI(TAG, "STA 模式已启动");
                break;
            case WIFI_EVENT_STA_CONNECTED:
                ESP_LOGI(TAG, "已连接到路由器");
                s_retry_count = 0;
                break;
            case WIFI_EVENT_STA_DISCONNECTED: {
                ESP_LOGE(TAG, "与路由器断开连接");

                xEventGroupClearBits(s_wifi_event_group, WIFI_CONNECTED_BIT);

                // 网络断开，立即通知LED开始闪烁
                led_network_status(false);

                wifi_event_sta_disconnected_t* event = (wifi_event_sta_disconnected_t*) event_data;
                ESP_LOGW(TAG, "断开原因: %d", (int)event->reason);

                // 统一策略：先重试，超过阈值才进入配网
                // （避免“保存了但偶发断线就强制开 AP 配网”的体验）
                if (s_retry_count < WIFI_MAX_RETRY) {
                    s_retry_count++;
                    ESP_LOGW(TAG, "自动重连重试 %d/%d", s_retry_count, WIFI_MAX_RETRY);
                    esp_wifi_connect();
                } else {
                    xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
                    ensure_provisioning_started();
                }
                break;
            }
            case WIFI_EVENT_SCAN_DONE:
                ESP_LOGI(TAG, "WiFi 扫描完成");
                break;
        }
    } else if (event_base == IP_EVENT) {
        if (event_id == IP_EVENT_STA_GOT_IP) {
            ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
            ESP_LOGI(TAG, "获得 IP 地址: " IPSTR, IP2STR(&event->ip_info.ip));
            xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
            xEventGroupClearBits(s_wifi_event_group, WIFI_FAIL_BIT);
            ensure_provisioning_stopped();

            led_network_status(true);  // ← 添加这行
        }
    }
}

// 启动 STA (用于扫描和连接)
static void start_sta(void) {
    if (!s_sta_netif) {
        s_sta_netif = esp_netif_create_default_wifi_sta();
    }
}

// 启动网页服务器
static void start_server(void) {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.stack_size = 8192;

    if (httpd_start(&g_server, &config) == ESP_OK) {
        // 注册路由
        // 修复点：这里修正了 handler 的引用，并统一使用 GET 方法
        httpd_uri_t uri_root = {.uri = "/", .method = HTTP_GET, .handler = root_handler};
        httpd_register_uri_handler(g_server, &uri_root);

        httpd_uri_t uri_rescan = {.uri = "/rescan", .method = HTTP_GET, .handler = rescan_handler};
        httpd_register_uri_handler(g_server, &uri_rescan);

        httpd_uri_t uri_input = {.uri = "/input", .method = HTTP_GET, .handler = input_handler};
        httpd_register_uri_handler(g_server, &uri_input);

        httpd_uri_t uri_save = {.uri = "/save", .method = HTTP_GET, .handler = save_handler}; // 修复了这里，原来是错误的变量名
        httpd_register_uri_handler(g_server, &uri_save);

        httpd_uri_t uri_icon = {.uri = "/favicon.ico", .method = HTTP_GET, .handler = favicon_handler};
        httpd_register_uri_handler(g_server, &uri_icon);

        ESP_LOGI(TAG, "网页服务器已启动，访问 http://192.168.4.1");
    }
}

// 尝试从 NVS 读取配置并自动连接
static bool try_connect(void) {
    nvs_handle_t nvs;
    char ssid[64] = {0};
    char pass[64] = {0};
    
    if (nvs_open("wifi", NVS_READONLY, &nvs) != ESP_OK) {
        ESP_LOGI(TAG, "NVS 中没有 WiFi 配置（未打开 namespace）");
        return false;
    }
    
    size_t len = sizeof(ssid);
    if (nvs_get_str(nvs, "ssid", ssid, &len) != ESP_OK) {
        nvs_close(nvs);
        ESP_LOGI(TAG, "NVS 中没有保存的 ssid");
        return false;
    }
    
    len = sizeof(pass);
    (void)nvs_get_str(nvs, "pass", pass, &len);
    nvs_close(nvs);

    // 设置 STA 配置并连接
    wifi_config_t sta_conf = {0};
    strncpy((char *)sta_conf.sta.ssid, ssid, sizeof(sta_conf.sta.ssid) - 1);
    strncpy((char *)sta_conf.sta.password, pass, sizeof(sta_conf.sta.password) - 1);
    sta_conf.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    sta_conf.sta.pmf_cfg.capable = true;
    sta_conf.sta.pmf_cfg.required = false;
    
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta_conf));
    esp_wifi_connect();
    
    ESP_LOGI(TAG, "已从 NVS 读取配置，正在自动连接: %s", ssid);
    return true;
}

// 主初始化函数
esp_err_t wifi_init(void) {
    // 1. 初始化基础组件
    esp_netif_init();// 初始化 TCP/IP 网络接口
    esp_event_loop_create_default();// 创建默认事件循环
    nvs_flash_init();// 初始化 NVS

    s_wifi_event_group = xEventGroupCreate();

    // 2. 注册事件监听
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler_sta, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler_sta, NULL, NULL));

    // 3. 初始化 WiFi 驱动
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));// 初始化 WiFi 驱动

    // 4. 先启动 STA，优先走“已配网自动连接”
    start_sta();// 启动 STA (用于扫描和连接)
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));// 设置为 STA 模式

    // 5. 启动 WiFi
    ESP_ERROR_CHECK(esp_wifi_start());// 启动 WiFi 驱动

    // 6. 如果已经在配网模式，直接返回成功（配网模式是正常运行状态）
    if (s_prov_started) {
        ESP_LOGI(TAG, "已在配网模式，跳过自动连接");
        return ESP_OK;
    }

    // 7. 尝试自动连接；成功拿到 IP 就完全跳过配网
    if (try_connect()) {
        EventBits_t bits = xEventGroupWaitBits(
            s_wifi_event_group,
            WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
            pdFALSE,
            pdFALSE,
            pdMS_TO_TICKS(WIFI_CONNECT_TIMEOUT_MS)
        );

        if (bits & WIFI_CONNECTED_BIT) {
            ESP_LOGI(TAG, "联网成功，跳过网页配网");
            return ESP_OK;
        }

        ESP_LOGW(TAG, "自动连接超时，进入网页配网");
    } else {
        ESP_LOGI(TAG, "未检测到保存的 WiFi 配置，进入网页配网");
    }

    // 7. 进入配网模式（AP + Web）
    ensure_provisioning_started();
    return ESP_FAIL;
}