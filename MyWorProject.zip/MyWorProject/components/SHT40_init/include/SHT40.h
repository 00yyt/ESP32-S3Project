#ifndef __SHT40_H__
#define __SHT40_H__

#include "driver/i2c.h"
#include "esp_err.h"

// SHT40 I2C配置
#define SHT40_I2C_PORT        I2C_NUM_1
#define SHT40_SCL_GPIO        5       // SCL引脚
#define SHT40_SDA_GPIO        4       // SDA引脚
#define SHT40_I2C_CLK_SPEED   400000  // I2C时钟频率

// SHT40 I2C地址（固定为0x44）
#define SHT40_ADDR            0x44

/**
 * @brief SHT40初始化（自动配置I2C）
 * 
 * @return esp_err_t 
 */
esp_err_t SHT40_init(void);

/**
 * @brief 读取温湿度数据
 * 
 * @param temperature 温度值（单位：℃）
 * @param humidity 湿度值（单位：%RH）
 * @return esp_err_t 
 */
esp_err_t SHT40_read(float *temperature, float *humidity);

#endif // __SHT40_H__