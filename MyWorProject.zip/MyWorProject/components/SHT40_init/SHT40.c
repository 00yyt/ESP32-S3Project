#include "SHT40.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

static const char *TAG = "SHT40";

// SHT40指令
#define SHT40_CMD_MEASURE_HIGH_PRECISION  0xFD  // 高精度测量模式
#define SHT40_CMD_MEASURE_MED_PRECISION   0xF6  // 中等精度测量模式
#define SHT40_CMD_MEASURE_LOW_PRECISION   0xE0  // 低精度测量模式
#define SHT40_CMD_READ_SERIAL             0x89  // 读取序列号
#define SHT40_CMD_SOFT_RESET              0x94  // 软件复位

// 静态变量
static i2c_port_t s_i2c_port = SHT40_I2C_PORT;
static uint8_t s_dev_addr = SHT40_ADDR;
static SemaphoreHandle_t s_i2c_mutex = NULL;

/**
 * @brief 向SHT40发送指令
 */
static esp_err_t sht40_send_cmd(uint8_t cmd)
{
    i2c_cmd_handle_t cmd_handle = i2c_cmd_link_create();
    i2c_master_start(cmd_handle);
    i2c_master_write_byte(cmd_handle, (s_dev_addr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd_handle, cmd, true);
    i2c_master_stop(cmd_handle);
    
    esp_err_t ret = i2c_master_cmd_begin(s_i2c_port, cmd_handle, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd_handle);
    
    return ret;
}

/**
 * @brief 从SHT40读取数据
 */
static esp_err_t sht40_read_data(uint8_t *data, size_t len)
{
    i2c_cmd_handle_t cmd_handle = i2c_cmd_link_create();
    i2c_master_start(cmd_handle);
    i2c_master_write_byte(cmd_handle, (s_dev_addr << 1) | I2C_MASTER_READ, true);
    
    if (len > 1) {
        i2c_master_read(cmd_handle, data, len - 1, I2C_MASTER_ACK);
    }
    i2c_master_read_byte(cmd_handle, data + len - 1, I2C_MASTER_NACK);
    
    i2c_master_stop(cmd_handle);
    
    esp_err_t ret = i2c_master_cmd_begin(s_i2c_port, cmd_handle, pdMS_TO_TICKS(100));
    i2c_cmd_link_delete(cmd_handle);
    
    return ret;
}

esp_err_t SHT40_init(void)
{
    // 创建I2C互斥锁（防止多任务并发访问）
    if (s_i2c_mutex == NULL) {
        s_i2c_mutex = xSemaphoreCreateMutex();
        if (s_i2c_mutex == NULL) {
            ESP_LOGE(TAG, "互斥锁创建失败");
            return ESP_ERR_NO_MEM;
        }
    }

    // 配置I2C参数
    i2c_config_t i2c_cfg = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = SHT40_SDA_GPIO,
        .scl_io_num = SHT40_SCL_GPIO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = SHT40_I2C_CLK_SPEED,
    };
    
    // 初始化I2C参数
    esp_err_t ret = i2c_param_config(s_i2c_port, &i2c_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C参数配置失败: %s", esp_err_to_name(ret));
        return ret;
    }
    
    // 安装I2C驱动
    ret = i2c_driver_install(s_i2c_port, I2C_MODE_MASTER, 0, 0, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C驱动安装失败: %s", esp_err_to_name(ret));
        return ret;
    }
    
    // 等待传感器上电稳定
    vTaskDelay(pdMS_TO_TICKS(50));
    
    // 软件复位（带重试）
    int retry = 0;
    for (retry = 0; retry < 3; retry++) {
        ret = sht40_send_cmd(SHT40_CMD_SOFT_RESET);
        if (ret == ESP_OK) {
            break;
        }
        ESP_LOGW(TAG, "软件复位失败(第%d次): %s，重试中...", retry + 1, esp_err_to_name(ret));
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "软件复位失败: %s", esp_err_to_name(ret));
        return ret;
    }
    
    // 等待复位完成（至少1ms）
    vTaskDelay(pdMS_TO_TICKS(10));
    
    ESP_LOGI(TAG, "SHT40初始化成功");
    return ESP_OK;
}

esp_err_t SHT40_read(float *temperature, float *humidity)
{
    if (!temperature || !humidity) {
        ESP_LOGE(TAG, "输出指针为空");
        return ESP_ERR_INVALID_ARG;
    }

    // 获取互斥锁（最多等待500ms，3个任务排队最坏情况~261ms）
    if (s_i2c_mutex && xSemaphoreTake(s_i2c_mutex, pdMS_TO_TICKS(500)) != pdTRUE) {
        ESP_LOGE(TAG, "I2C总线被占用，获取锁超时");
        return ESP_ERR_TIMEOUT;
    }

    // 发送高精度测量指令
    esp_err_t ret = sht40_send_cmd(SHT40_CMD_MEASURE_HIGH_PRECISION);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "发送测量指令失败: %s", esp_err_to_name(ret));
        if (s_i2c_mutex) xSemaphoreGive(s_i2c_mutex);
        return ret;
    }

    // 等待测量完成（高精度模式最大需要80ms）
    vTaskDelay(pdMS_TO_TICKS(85));

    // 读取6字节数据（温度高字节、温度低字节、温度CRC、湿度高字节、湿度低字节、湿度CRC）
    uint8_t data[6] = {0};
    ret = sht40_read_data(data, 6);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "读取数据失败: %s", esp_err_to_name(ret));
        if (s_i2c_mutex) xSemaphoreGive(s_i2c_mutex);
        return ret;
    }

    // 释放互斥锁
    if (s_i2c_mutex) xSemaphoreGive(s_i2c_mutex);

    // 提取温度和湿度原始数据
    uint16_t raw_temp = (data[0] << 8) | data[1];
    uint16_t raw_humidity = (data[3] << 8) | data[4];

    // 转换为实际温度和湿度值
    *temperature = -45.0f + 175.0f * (float)raw_temp / 65535.0f;
    *humidity = -6.0f + 125.0f * (float)raw_humidity / 65535.0f;

    // 确保湿度在合理范围内
    if (*humidity < 0.0f) *humidity = 0.0f;
    if (*humidity > 100.0f) *humidity = 100.0f;

    ESP_LOGD(TAG, "读取温度: %.2f°C, 湿度: %.2f%%RH", *temperature, *humidity);
    return ESP_OK;
}