#ifndef __KEY_H__
#define __KEY_H__

#include "esp_err.h"

#define KEY_GPIO_NUM 6
#define KEY_LONG_PRESS_TIME_MS 5000
#define KEY_DEBOUNCE_TIME_MS 50

void key_init(void);
void clear_wifi_config(void);

#endif /* __KEY_H__ */