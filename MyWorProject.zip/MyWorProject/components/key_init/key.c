#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "key.h"
#include "led.h"
#include "Buzzer.h"



static const char *TAG = "key";

void clear_wifi_config(void) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open("wifi", NVS_READWRITE, &nvs_handle);
    if (err == ESP_OK) {
        err = nvs_erase_all(nvs_handle);
        if (err == ESP_OK) {
            err = nvs_commit(nvs_handle);
            if (err == ESP_OK) {
                ESP_LOGI(TAG, "WiFi 配置已清空，设备将重启");

                // 蜂鸣器响一下提示用户 WiFi 配置已清空
                Buzzer_On();
                vTaskDelay(pdMS_TO_TICKS(500)); // 响 500ms
                Buzzer_Off();



                
                esp_restart();
            } else {
                ESP_LOGE(TAG, "NVS commit 失败: %s", esp_err_to_name(err));
            }
        } else {
            ESP_LOGE(TAG, "NVS erase 失败: %s", esp_err_to_name(err));
        }
        nvs_close(nvs_handle);
    } else {
        ESP_LOGE(TAG, "NVS open 失败: %s", esp_err_to_name(err));
    }
}

static void key_task(void *pvParameters) {
    bool last_state = gpio_get_level(KEY_GPIO_NUM);
    bool current_state = last_state;
    TickType_t press_start_tick = 0;
    bool press_detected = false;
    bool long_press_detected = false;

    while (1) {
        current_state = gpio_get_level(KEY_GPIO_NUM);

        if (current_state != last_state) {
            vTaskDelay(pdMS_TO_TICKS(KEY_DEBOUNCE_TIME_MS));
            current_state = gpio_get_level(KEY_GPIO_NUM);
        }

        if (!current_state && last_state) {
            press_start_tick = xTaskGetTickCount();
            press_detected = true;
            long_press_detected = false;
            ESP_LOGI(TAG, "按键按下");
        }

        if (!current_state && press_detected && !long_press_detected) {
            TickType_t elapsed = xTaskGetTickCount() - press_start_tick;
            if (pdTICKS_TO_MS(elapsed) >= KEY_LONG_PRESS_TIME_MS) {
                ESP_LOGW(TAG, "检测到长按 %d 毫秒，清空 WiFi 配置", (int)pdTICKS_TO_MS(elapsed));
                clear_wifi_config();
                long_press_detected = true;
            }
        }

        if (current_state && !last_state && press_detected) {
            TickType_t elapsed = xTaskGetTickCount() - press_start_tick;
            if (!long_press_detected && pdTICKS_TO_MS(elapsed) < KEY_LONG_PRESS_TIME_MS) {
                ESP_LOGI(TAG, "短按 %d 毫秒", (int)pdTICKS_TO_MS(elapsed));
            }
            press_detected = false;
        }

        last_state = current_state;
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

void key_init(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << KEY_GPIO_NUM),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    esp_err_t err = gpio_config(&io_conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "gpio_config 失败: %s", esp_err_to_name(err));
        return;
    }

    ESP_LOGI(TAG, "按键初始化完成，GPIO%d，当前电平=%d", KEY_GPIO_NUM, gpio_get_level(KEY_GPIO_NUM));

    BaseType_t ok = xTaskCreate(key_task, "key_task", 4096, NULL, 5, NULL);
    if (ok != pdPASS) {
        ESP_LOGE(TAG, "xTaskCreate(key_task) 失败");
    }
}