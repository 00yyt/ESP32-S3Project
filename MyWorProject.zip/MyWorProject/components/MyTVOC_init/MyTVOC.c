#include "MyTVOC.h"
#include "Myuart.h"

TVOC301_Data_TypeDef tvoc301 = {0};

void TVOC301_Decode(uint8_t *buf)
{
    uint8_t i, sum = 0;
    
    tvoc301.valid = 0;
    
    if(buf[0] != 0x2C || buf[1] != 0xE4) {
        return;
    }
    
    for(i = 0; i < 8; i++) {
        sum += buf[i];
    }
    
    if(sum != buf[8]) {
        return;
    }
    
    tvoc301.tvoc = (buf[2] << 8) | buf[3];
    tvoc301.hcho = (buf[4] << 8) | buf[5];
    tvoc301.eco2 = (buf[6] << 8) | buf[7];
    tvoc301.valid = 1;
}

void TVOC301_Get_Data(uint16_t *tvoc, uint16_t *hcho, uint16_t *eco2)
{
    if(tvoc != NULL) *tvoc = tvoc301.tvoc;
    if(hcho != NULL) *hcho = tvoc301.hcho;
    if(eco2 != NULL) *eco2 = tvoc301.eco2;
}