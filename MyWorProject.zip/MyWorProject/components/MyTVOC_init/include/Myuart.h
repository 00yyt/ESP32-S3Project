#ifndef MYUART_H
#define MYUART_H

#include "driver/uart.h"
#include "driver/gpio.h"

// 串口配置宏
#define UART_PORT_NUM      UART_NUM_1
#define UART_BAUD_RATE     9600
#define UART_TX_PIN        GPIO_NUM_17
#define UART_RX_PIN        GPIO_NUM_18
#define TVOC301_LEN        9   // TVOC301数据包长度

// 全局变量外部声明（关键：让其他文件能访问）
extern uint8_t USART1_RX_Buf[];
extern uint8_t USART1_RX_Count;
extern uint8_t USART1_Flag;

// 函数声明（让main.c调用UART_Init不报错）
void UART_Init(void);

#endif