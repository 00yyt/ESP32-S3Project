#ifndef __MYTVOC_H__
#define __MYTVOC_H__

#include <stdint.h>

typedef struct {
    uint16_t tvoc;
    uint16_t hcho;
    uint16_t eco2;
    uint8_t valid;
} TVOC301_Data_TypeDef;

extern TVOC301_Data_TypeDef tvoc301;

void TVOC301_Decode(uint8_t *buf);
void TVOC301_Get_Data(uint16_t *tvoc, uint16_t *hcho, uint16_t *eco2);

#endif