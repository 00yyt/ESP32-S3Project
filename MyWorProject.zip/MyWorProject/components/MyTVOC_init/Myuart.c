#include "Myuart.h"
#include "driver/uart.h"
#include "driver/gpio.h"    // 补充GPIO头文件，识别GPIO_NUM_xx
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h" // 队列头文件

uint8_t USART1_RX_Buf[TVOC301_LEN] = {0};
uint8_t USART1_RX_Count = 0;
uint8_t USART1_Flag = 0;
static QueueHandle_t uart1_queue = NULL;

static void uart_event_task(void *pvParameters)
{
    uart_event_t event;
    // size_t buffered_size;  // 未使用，注释/删除消除警告
    
    for(;;) {
        // 移除过时的 (portTickType) 强转
        if(xQueueReceive(uart1_queue, (void *)&event, portMAX_DELAY)) {
            switch(event.type) {
                case UART_DATA:
                    uart_read_bytes(UART_PORT_NUM, &USART1_RX_Buf[USART1_RX_Count], event.size, portMAX_DELAY);
                    USART1_RX_Count += event.size;
                    
                    if(USART1_RX_Count >= TVOC301_LEN) {
                        USART1_Flag = 1;
                        USART1_RX_Count = 0;
                    }
                    break;
                case UART_FIFO_OVF:
                    uart_flush_input(UART_PORT_NUM);
                    xQueueReset(uart1_queue);
                    USART1_RX_Count = 0;
                    break;
                default:
                    break;
            }
        }
    }
}

void UART_Init(void)
{
    uart_config_t uart_config = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    uart_param_config(UART_PORT_NUM, &uart_config);
    uart_set_pin(UART_PORT_NUM, UART_TX_PIN, UART_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_driver_install(UART_PORT_NUM, 1024 * 2, 0, 10, &uart1_queue, 0);
    
    xTaskCreate(uart_event_task, "uart_event_task", 2048, NULL, 12, NULL);
}