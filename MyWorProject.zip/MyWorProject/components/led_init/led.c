#include "led.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "cloud.h"
#include <stdio.h>


#define TAG "led"

static bool current_led_state = false; // 当前LED状态，false=关闭，true=点亮
static bool network_connected = false;  // 网络连接状态（初始为false，设备启动时无网络则闪烁）
static QueueHandle_t network_status_queue = NULL; // 网络状态消息队列
// 函数原型声明
static void led_network_task(void *pvParameters);

// 发布LED状态到MQTT平台


void led_init(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = ((1ULL << netLED_GPIO_NUM) | (1ULL << redLED_GPIO_NUM)),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };






    gpio_config(&io_conf);
    
    // 默认关闭 LED（高电平）
    gpio_set_level(netLED_GPIO_NUM, 1);
    gpio_set_level(redLED_GPIO_NUM, 0);
    current_led_state = false;
    
    // 创建网络状态消息队列
    network_status_queue = xQueueCreate(1, sizeof(bool));
    
    // 创建网络状态指示任务
    xTaskCreate(led_network_task, "led_network_task", 2048, NULL, 4, NULL);
    
    ESP_LOGI(TAG, "netLED 初始化完成，GPIO%d，高电平关闭", netLED_GPIO_NUM);
    ESP_LOGI(TAG, "redLED 初始化完成，GPIO%d，高电平关闭", redLED_GPIO_NUM);

}

void net_led_on(void) {
    gpio_set_level(netLED_GPIO_NUM, 0); // 高电平点亮
    ESP_LOGI(TAG, "LED 点亮");
   
   
}

void net_led_off(void) {
    gpio_set_level(netLED_GPIO_NUM, 1); // 高电平关闭
   
    ESP_LOGI(TAG, "LED 关闭");
    
}

void red_led_on(void) {
    gpio_set_level(redLED_GPIO_NUM, 1); // 高电平点亮
    ESP_LOGI(TAG, "redLED 点亮");
   
   
}

void red_led_off(void) {
    gpio_set_level(redLED_GPIO_NUM, 0); // 低电平关闭
   
    ESP_LOGI(TAG, "redLED 关闭");
    
}

void net_led_toggle_state(void) {
    current_led_state = !current_led_state;
    gpio_set_level(netLED_GPIO_NUM, current_led_state ? 0 : 1);
    ESP_LOGI(TAG, "LED 状态切换: %s", current_led_state ? "点亮" : "关闭");
   
}


//网络状态指示灯任务
static void led_network_task(void *pvParameters) {
    bool connected;
    while (1) {
        // 使用 0 超时，不阻塞等待消息
        if (xQueueReceive(network_status_queue, &connected, 0) == pdTRUE) {
            network_connected = connected;
            ESP_LOGI(TAG, "网络状态更新: %s", connected ? "已连接" : "已断开");
        }
        
        if (!network_connected) {
            // 网络断开：LED 500ms闪烁（不向平台上报）
            gpio_set_level(netLED_GPIO_NUM, 0); // 点亮
            vTaskDelay(pdMS_TO_TICKS(500));
            gpio_set_level(netLED_GPIO_NUM, 1); // 熄灭
            vTaskDelay(pdMS_TO_TICKS(500));
        } else {
            // 网络连接：LED常灭
            gpio_set_level(netLED_GPIO_NUM, 1); // 熄灭
            vTaskDelay(pdMS_TO_TICKS(100)); // 短延时
        }
    }
}

//网络状态指示灯更新
void led_network_status(bool connected) {
    if (network_status_queue) {
        bool dummy;
        while (uxQueueMessagesWaiting(network_status_queue) > 0) {
            xQueueReceive(network_status_queue, &dummy, 0);
        }
        xQueueSend(network_status_queue, &connected, 0);
    }
}