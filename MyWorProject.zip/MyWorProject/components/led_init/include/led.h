#ifndef __LED_H__
#define __LED_H__

#define netLED_GPIO_NUM 2

#define redLED_GPIO_NUM 3



#include "esp_err.h"
#include <stdbool.h>

void led_init(void);
void net_led_on(void);
void net_led_off(void);
void net_led_toggle_state(void);
void led_network_status(bool connected);
void red_led_on(void);
void red_led_off(void);


#endif