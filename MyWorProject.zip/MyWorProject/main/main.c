#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_err.h"
#include "led.h"
#include "SHT40.h"
#include "Buzzer.h"
#include "Myuart.h"
#include "wifi.h"
#include "cloud.h"
#include "key.h"
#include "MyTVOC.h"

float temperature, humidity;
uint16_t tvoc, hcho, eco2;



// onenet 物联网平台属性上报格式（浮点数）
#define MQTT_PUBLISH_FORMAT "{\"id\":\"123\",\"params\":{\"%s\":{\"value\":%.2f}}}"
// onenet 物联网平台属性上报格式（整数）
#define MQTT_PUBLISH_FORMAT_INT "{\"id\":\"123\",\"params\":{\"%s\":{\"value\":%d}}}"

// 数据上报任务（每10秒一次）
void data_report_task(void *arg) {
    (void)arg;
    
    while (1) {
     

        // 读取温湿度并上报
        if (SHT40_read(&temperature, &humidity) == ESP_OK) {
            // 温度
            char temp_data[128];
            snprintf(temp_data, sizeof(temp_data), MQTT_PUBLISH_FORMAT, "temp", temperature);
            ESP_LOGI("DATA_REPORT", "温度数据: %s", temp_data);
            mqtt_publish(MQTT_PUBLISH_TOPIC, temp_data, 0, 0);

            // 湿度
            char humi_data[128];
            snprintf(humi_data, sizeof(humi_data), MQTT_PUBLISH_FORMAT, "humi", humidity);
            ESP_LOGI("DATA_REPORT", "湿度数据: %s", humi_data);
            mqtt_publish(MQTT_PUBLISH_TOPIC, humi_data, 0, 0);
        }

        // 读取TVOC、eCO2、HCHO并上报
        if (tvoc301.valid) {
            // eCO2 (二氧化碳当量) - 使用整数格式
            char eco2_data[128];
            snprintf(eco2_data, sizeof(eco2_data), MQTT_PUBLISH_FORMAT_INT, "eco2", eco2);
            ESP_LOGI("DATA_REPORT", "eCO2数据: %s", eco2_data);
            mqtt_publish(MQTT_PUBLISH_TOPIC, eco2_data, 0, 0);

            // TVOC (总挥发性有机物) - 使用整数格式
            char tvoc_data[128];
            snprintf(tvoc_data, sizeof(tvoc_data), MQTT_PUBLISH_FORMAT_INT, "tvoc", tvoc);
            ESP_LOGI("DATA_REPORT", "TVOC数据: %s", tvoc_data);
            mqtt_publish(MQTT_PUBLISH_TOPIC, tvoc_data, 0, 0);

            // HCHO (甲醛) - 使用整数格式
            char hcho_data[128];
            snprintf(hcho_data, sizeof(hcho_data), MQTT_PUBLISH_FORMAT_INT, "hcho", hcho);
            ESP_LOGI("DATA_REPORT", "HCHO数据: %s", hcho_data);
            mqtt_publish(MQTT_PUBLISH_TOPIC, hcho_data, 0, 0);
        }

        // 每10秒上报一次
        vTaskDelay(pdMS_TO_TICKS(10000));
    }
}


//读传感器数据并打印
void read_sensors_task(void *arg) {
    (void)arg;
    
    while (1) {
      
          if(USART1_Flag == 1) {
            TVOC301_Decode(USART1_RX_Buf);
            USART1_Flag = 0;
            
            if(tvoc301.valid) {
                TVOC301_Get_Data(&tvoc, &hcho, &eco2);
               
               ESP_LOGI("TVOC301", "TVOC: %d ppb, HCHO: %d ppb, eCO2: %d ppm", tvoc, hcho, eco2);
            }



        }

         esp_err_t ret = SHT40_read(&temperature, &humidity);
        if (ret == ESP_OK) {
            ESP_LOGI("SHT40", "Temperature: %.2f °C, Humidity: %.2f %%", temperature, humidity);
        } else {
            ESP_LOGE("SHT40", "读取失败: %s", esp_err_to_name(ret));
        }




        // 每秒更新一次LCD
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}




// 温湿度阈值检测任务
void threshold_check_task(void *arg) {
    (void)arg;
    bool alarm_active = false;
    
    while (1) {
        if (SHT40_read(&temperature, &humidity) == ESP_OK) {
            bool temp_alarm = false;
            bool humi_alarm = false;
            
            // 检测温度是否超出阈值
            if (temperature > temp_high_threshold) {
                ESP_LOGW("ALARM", "温度过高: %.2f°C > %.2f°C", temperature, temp_high_threshold);
                temp_alarm = true;
            } else if (temperature < temp_low_threshold) {
                ESP_LOGW("ALARM", "温度过低: %.2f°C < %.2f°C", temperature, temp_low_threshold);
                temp_alarm = true;
            }
            
            // 检测湿度是否超出阈值
            if (humidity > humi_high_threshold) {
                ESP_LOGW("ALARM", "湿度过高: %.2f%%RH > %.2f%%RH", humidity, humi_high_threshold);
                humi_alarm = true;
            } else if (humidity < humi_low_threshold) {
                ESP_LOGW("ALARM", "湿度过低: %.2f%%RH < %.2f%%RH", humidity, humi_low_threshold);
                humi_alarm = true;
            }
            
            // 如果有任何报警，蜂鸣器响
            if (temp_alarm || humi_alarm) {
                if (!alarm_active) {
                    ESP_LOGI("ALARM", "蜂鸣器报警启动");
                    alarm_active = true;
                }
                Buzzer_On();
                red_led_on();
                vTaskDelay(pdMS_TO_TICKS(500));
                Buzzer_Off();
                red_led_off();
                vTaskDelay(pdMS_TO_TICKS(500));
            } else {
                if (alarm_active) {
                    ESP_LOGI("ALARM", "蜂鸣器报警停止");
                    alarm_active = false;
                }
                Buzzer_Off();
                red_led_off();
                vTaskDelay(pdMS_TO_TICKS(1000));
            }
        } else {
            Buzzer_Off();
            red_led_off();
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
}



void app_main(void)
{
    led_init();
    


     // 初始化WiFi配网系统
    wifi_init();
    


   ESP_ERROR_CHECK(cloud_init());
    // 初始化按键功能
    key_init();

    UART_Init();

    
    
   // 初始化SHT40传感器（非致命，失败不崩溃）
   esp_err_t sht40_ret = SHT40_init();
   if (sht40_ret != ESP_OK) {
       ESP_LOGW("SHT40", "SHT40初始化失败: %s，传感器数据将不可用", esp_err_to_name(sht40_ret));
   }
  

   
    Buzzer_Init();


      // // 创建数据上报任务（每10秒一次）
    xTaskCreate(data_report_task, "data_report", 4096, NULL, 5, NULL);

    //创建读取传感器数据的任务
    xTaskCreate(read_sensors_task, "TVOC301_read_task", 4096, NULL, 3, NULL);

     // 创建温湿度阈值检测任务
    xTaskCreate(threshold_check_task, "threshold_check", 4096, NULL, 3, NULL);


    while (1) {

       

    //     red_led_on();
    //  //   Buzzer_On();
    //     vTaskDelay(1000 / portTICK_PERIOD_MS);
    //     red_led_off();
    //    // Buzzer_Off();
    //     vTaskDelay(1000 / portTICK_PERIOD_MS);

         vTaskDelay(1000 / portTICK_PERIOD_MS);

    }
}